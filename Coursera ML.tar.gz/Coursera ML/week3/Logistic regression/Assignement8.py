from math import exp
from sklearn.metrics import roc_auc_score
import numpy as np
import pandas

# x:1:n y:1x1 w:1xn der:in[1:n]                 n = 2
def derivative(x, y, w, der):
	'''
	Calculate derivatives
	'''
	result = 0
	for i in range(len(y)):
		x_i = x.loc[i, :]
		y_i = y.loc[i]
		index = -y_i * sum(np.multiply(x_i, w))
		index = exp(index)
		result += (-y_i * x_i[der] * index) / (1 + index) 
	#print result
	return result


data = pandas.read_csv('data-logistic.csv', header=None)
labels = data.loc[:,0]
train = data.loc[:,1:]
for i in range(len(labels)):
	if labels[i] == 0:
		labels[i] = -1

# w: inicialization
w = [0, 0]
w_ = [0, 0]
for i in range(100):
	#w = [w_[i] - 0.1 * derivative(train, test, w_, i) for i in [0,1] ]
	w[0] = w_[0] - 0.1 * derivative(train, labels, w_, 1) 
	w[1] = w_[1] - 0.1 * derivative(train, labels, w_, 2) 
	w_[0] = w[0]
	w_[1] = w[1]
	print w

res = []
for i in range(len(labels)):	
	print res.append(-labels[i] * sum(np.multiply(train.loc[i, :], w)))
print roc_auc_score(labels, res)
