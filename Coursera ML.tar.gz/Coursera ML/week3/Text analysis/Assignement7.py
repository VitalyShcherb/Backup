from sklearn.datasets import fetch_20newsgroups
newsgroups = fetch_20newsgroups()
								#categories=['alt.atheism', 'sci.space'])
#data = newsgroups.data
#lables = newsgroups.target
#print data
